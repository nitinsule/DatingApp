import { InjectionToken } from '@angular/core';

export const JWT_OPTIONS = new InjectionToken('JWT_OPTIONS');
